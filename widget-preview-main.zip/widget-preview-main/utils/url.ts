import { redirect } from "next/navigation";

export function goDeveloper() {
  redirect("https://developer.dodoex.io");
}

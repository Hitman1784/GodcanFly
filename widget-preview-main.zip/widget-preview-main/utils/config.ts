export const API_DOMAIN =
  (process.env.REACT_APP_API_DOMAIN as string) ?? "dodoex.io";
export const CRYPTO_KEY = process.env.REACT_APP_CRYPTO_KEY as string;
